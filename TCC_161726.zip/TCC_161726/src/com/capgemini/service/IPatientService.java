package com.capgemini.service;

import com.capgemini.exception.PatientsException;

import ccom.capgemini.tcc.bean.Patientbean;


public interface IPatientService {
	public String addPatientDetails(Patientbean patientbean) throws PatientsException;
}
