package com.capgemini.tcc.dao;
import com.capgemini.exception.PatientsException;

import ccom.capgemini.tcc.bean.Patientbean;
public interface IPatientDAO {
	public String addPatientDetails(Patientbean patientbean) throws PatientsException;
}





